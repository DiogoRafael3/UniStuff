package Boggle;

public class InvalidNodeException extends Exception{
    public InvalidNodeException(String message)
    {
        super(message);
    }
}
